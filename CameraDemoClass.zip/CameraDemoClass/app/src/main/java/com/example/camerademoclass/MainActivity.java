package com.example.camerademoclass;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageView;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private ImageView imageView, imageView1, imageView2, imageView3;
    private File imageDir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        imageView = findViewById(R.id.imageView);
        imageView1 = findViewById(R.id.imageView);
        imageView2 = findViewById(R.id.imageView);
        imageView3 = findViewById(R.id.imageView);

        showLatestImage();
    }

    public void startCamera(View view) {
        Intent cam_intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        File imageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        File imageFile = new File(imageDir, "IMG_" + timeStamp + ".png");
        Uri imageUri = FileProvider.getUriForFile(this, "com.example.fileprovider", imageFile);
        cam_intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);

        startActivityForResult(cam_intent, 1);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK);{
            showLatestImage();
        }

    }

    private void showLatestImage() {
        String[] allFiles = imageDir.list();

        if (allFiles != null && allFiles.length > 1){

            Arrays.sort(allFiles, Collections.reverseOrder());
            String n0ImagePath = new File(imageDir, allFiles[0]).getAbsolutePath();
            Bitmap n0image = BitmapFactory.decodeFile(n0ImagePath);
            imageView.setImageBitmap(n0image);

        }

    }
}
